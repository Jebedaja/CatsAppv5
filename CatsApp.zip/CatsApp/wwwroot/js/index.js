﻿// index.js

document.getElementById("nextCatButton").addEventListener("click", function () {
    window.location.href = '/Cats/Index'; // Przekierowanie do akcji Index w kontrolerze CatsController
});
